from django.contrib import admin
from .models import Student_Info
# Register your models here.
admin.site.register(Student_Info)
