from django.apps import AppConfig


class EduperappConfig(AppConfig):
    name = 'EduPerApp'
