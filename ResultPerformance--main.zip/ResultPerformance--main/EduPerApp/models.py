from django.db import models
from django.contrib.auth.models import User
# Create your models here.


class Student_Info(models.Model):
    Name = models.CharField(max_length=200)
    Roll = models.IntegerField()
    Reg = models.IntegerField()
    Batch = models.CharField(max_length=200)
    Class_Test_Marks = models.DecimalField(decimal_places=2, max_digits=15)
    Midterm_Marks = models.DecimalField(decimal_places=2, max_digits=15)
    Attendance_Marks = models.DecimalField(decimal_places=2, max_digits=15)
    Presentation_Marks = models.DecimalField(decimal_places=2, max_digits=15)
    Final_Exam_Marks = models.DecimalField(decimal_places=2, max_digits=15)

    def __str__(self):
        return self.name
